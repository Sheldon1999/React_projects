import React from 'react';
import ReactDOM from 'react-dom';
import CommentDetail from './CommentDetail';
import ApprovalCard from './ApprovalCard';

const App = () => {
    return (
        <div className="ui container comments">
            <ApprovalCard>
                <div>
                    <h4>Warning!</h4>
                    Are you sure about this !!
                </div>
            </ApprovalCard>
            <ApprovalCard>
                <CommentDetail 
                author="alex" 
                timeAgo="Today at 6:00 AM" />
            </ApprovalCard>
            <ApprovalCard>
                <CommentDetail 
                author="sam" 
                timeAgo="yesterday at 5:00 PM" />
            </ApprovalCard>
            <ApprovalCard>
                <CommentDetail 
                author="alicia" 
                timeAgo="yesterday at 3:00 PM" />
            </ApprovalCard>
        </div>
    );
}

ReactDOM.render(<App />, document.querySelector('#root'));