import React from 'react';
import './SeasonDisplay.css';

// make an object for containing details of
const seasonConfig = {
    summer: {
        text: '!!!! Hayee garmi',
        iconName: 'sun'
    },
    winter: {
        text: 'ohohhohhh yrr, bahutt thand hai',
        iconName: 'snowflake'
    }
}


const getSeason = (lat, month) => {
    if(month > 2 && month < 9){
        return lat > 0 ? 'summer' : 'winter';
    }

    else{
        return lat > 0 ? 'winter' : 'summer';
    }
}

const Seasondisplay = (props) => {
    
    const Season = getSeason(props.lat, new Date().getMonth());
    //text we wnt to print out according to season
    //using ternary expression of jsx
    //const text = Season === 'winter' ? 'ohohhohhh yrr, bahutt thad hai' : ' !!!! Hayee garmi';
    //const icon = Season === 'winter' ? 'snowflake' : 'sun';
    const { text , iconName } = seasonConfig[Season];

    return (
        <div className={ `season-display ${Season}` } >
            <i className={ `icon-left massive ${iconName} loading icon` } ></i>
            <h1>{text}</h1>
            <i className={ `icon-right massive ${iconName} loading icon` } ></i>
        </div>
    );
};

export default Seasondisplay;