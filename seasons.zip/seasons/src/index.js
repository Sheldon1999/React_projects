import React from 'react';
import ReactDOM from 'react-dom';
import SeasonDisplay from './SeasonDisplay';
import Spinner from './Spinner';

class App extends React.Component {

    // we can initialize state without constructor:
    // but the fashion is different:
    state = { lat: null, Error: '' };

    // using this function rather than constructor
    // is prefered according to react community
    // run just after component initializes
    componentDidMount(){    
        window.navigator.geolocation.getCurrentPosition(
            (position) => {
                this.setState({lat: position.coords.latitude})
            },
            (err) => {
                this.setState({Error: err.message})
            }
        );
    }

    renderComponent(){
        if(this.state.lat && !this.state.Error)
        return(
            // passing property to the child component:
            <SeasonDisplay lat={this.state.lat} />
        );
        else if(!this.state.lat && this.state.Error)
        return(
            <div>
                <p>{this.state.Error}</p>
            </div>
        );
        else
        return (
            <Spinner message="Please accept location request" />
        );
    }

    render() {
        return(
            <div className="border red">
                {this.renderComponent()};
            </div>
        );
    }
}

ReactDOM.render(
    <App />,
    document.querySelector('#root')
);